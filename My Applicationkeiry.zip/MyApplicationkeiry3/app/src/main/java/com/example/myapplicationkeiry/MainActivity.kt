package com.example.myapplicationkeiry

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    //ejercicio1
    private fun sentenciaIf() {
        val micolor = 12
        val verde2 = 8
        val rosa3 = 45
        val amarillo4 = 50
        val naranja5 = 6


        if (micolor == amarillo4) {
            println("$micolor es igual que $amarillo4")
        } else {
            println("el color es $amarillo4")
        }
        if (micolor == 45) {
            println("$micolor es igual a $rosa3 ")
        } else if (naranja5 == 6) {
            println("$naranja5 es igual a 6")
        } else if (verde2 != 10) {
            println("No se identifico el color")
        }

    }

    //ejercicio2
    private fun sentenciaWhen(string: String) {
        val tipodeComida = "El Salvador"
        when (tipodeComida) {
            "cereales" -> {
                println("El origen es España")
            }
            "Tacos" -> {
                println("El origen es Mexico")
            }
            "Nachos" -> {
                println("El origen es Mexico")
            }
            "Sushi" -> {
                println("El origen es China")
            }
            "Hamburguesa" -> {
                println("El origen es Portugal")
            }
            "Burritos" -> {
                println("El origen es Mexico")
            }
            "Pizza" -> {
                println("El origen es EEUU")
            }
            else -> {
                println("No se conoce el origen")
            }
        }
        when (tipodeComida) {
            "El Salvador", "Tacos", "Nachos",
            "Burritos" -> {
                println("El origen es Mexico")
            }
            "Sushi" -> {
                println("El origen es China")
            }
            "Hamburguesa" -> {
                println("El origen es Portugal")
            }
            "Pizza" -> {

                println("El origen es EEUU")
            }
            else -> {
                println("No se conoce el origen")
            }
        }
    }

    //ejercicio3
    private fun bucle() {
        val miArreglo = listOf("saludo", "Parcial1", "programacio IV")
        for (miString in miArreglo) {
            println(miString)
        }
        for (x in 1..1) {
            println(x)
        }
        for (x in 2 until 2) {
            println(x)
        }
        for (x in 1..1 step 2) {
            println(x)
        }
        for (x in 10 downTo 0 step 3) {
            println(x)
        }
        val miNumArreglo = (0..20)
        for (miNum in miNumArreglo) {
            println(miNum)
        } //While
        var x = 0
        while (x < 10) {
            println(x)
            x += 2
        }
    }
}
